Qt 可视化界面代码说明
============

本项目真实主界面是 Flask + Web 控制台；本包额外提供 Qt 桌面入口，满足课程中 Qt 可视化界面提交要求。
qt_launcher.py 会启动或复用 127.0.0.1:5000 的 Flask 服务，并优先用 QtWebEngine 嵌入 Web 控制台。
若环境缺少 PySide6，请先执行 pip install -r requirements-qt.txt。
