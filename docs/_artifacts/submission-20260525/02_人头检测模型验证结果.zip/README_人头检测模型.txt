人头检测模型验证结果说明
============

本包整理 YOLO 训练/验证输出，包含 results.csv、results.png、P/R/PR/F1 曲线、混淆矩阵和训练/验证样例图。
best.pt 与 last.pt 为训练权重文件，便于复核模型产物完整性。
