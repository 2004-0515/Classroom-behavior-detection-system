随机点名核心代码说明
==========

随机点名功能基于当前检测结果中的人头候选目标，从可见目标中随机抽取并展示。
核心逻辑涉及 static/app/lib/inspector.js 的候选目标提取与随机选择，以及 static/app/components/random-call.js 的结果渲染。
templates/app_shell.html 提供随机点名按钮与弹窗结构，static/css/app.css 提供弹窗布局样式。
