前端文件完整代码说明
==========

本包包含当前 Web 可视化界面模板、CSS、ES module 前端代码和图表库。
主要入口为 templates/app_shell.html 与 static/app/main.js。
前端单测由 scripts/frontend_service_tests.py 递归执行 static/app/**/*.test.js。
